// Arbitrary response 6th order Biquad (DF2TSOS)
// Coefficient b0 stage 1 = 0x7b542	 (-19134)	(-0.291962) 
// Coefficient b1 stage 1 = 0x7ccf1	 (-13071)	(-0.199448) 
// Coefficient b2 stage 1 = 0x7b547	 (-19129)	(-0.291885) 
// Coefficient a0 stage 1 = 0x78441	 (-31679)	(-0.483383) 
// Coefficient a1 stage 1 = 0x0893a	 (35130)	(0.536041) 
// Coefficient b0 stage 2 = 0x07631	 (30257)	(0.461685) 
// Coefficient b1 stage 2 = 0x0064f	 ( 1615)	(0.024643) 
// Coefficient b2 stage 2 = 0x0762f	 (30255)	(0.461655) 
// Coefficient a0 stage 2 = 0x7b6aa	 (-18774)	(-0.286469) 
// Coefficient a1 stage 2 = 0x0e55c	 (58716)	(0.895935) 
// Coefficient b0 stage 3 = 0x0a6ba	 (42682)	(0.651276) 
// Coefficient b1 stage 3 = 0x0a16f	 (41327)	(0.630600) 
// Coefficient b2 stage 3 = 0x000fa	 (  250)	(0.003815) 
// Coefficient a0 stage 3 = 0x7bbbf	 (-17473)	(-0.266617) 
// Coefficient a1 stage 3 = 0x00019	 (   25)	(0.000381) 
const int32_t biq_correction_2x[15] = {
-19134, 
-13071, 
-19129, 
-31679, 
35130, 
30257, 
1615, 
30255, 
-18774, 
58716, 
42682, 
41327, 
250, 
-17473, 
25, 
};
// filter_coeff[0] = -19134; 
// filter_coeff[1] = -13071; 
// filter_coeff[2] = -19129; 
// filter_coeff[3] = -31679; 
// filter_coeff[4] = 35130; 
// filter_coeff[5] = 30257; 
// filter_coeff[6] = 1615; 
// filter_coeff[7] = 30255; 
// filter_coeff[8] = -18774; 
// filter_coeff[9] = 58716; 
// filter_coeff[10] = 42682; 
// filter_coeff[11] = 41327; 
// filter_coeff[12] = 250; 
// filter_coeff[13] = -17473; 
// filter_coeff[14] = 25; 
